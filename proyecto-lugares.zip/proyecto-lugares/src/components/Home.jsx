import React from 'react'
import Slider from 'react-slick'
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

function Home() {
  const configuracion = {
    className: 'center',
    dots: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    speed: 2000,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    centerMode: true,
    centerPadding: '60px'
}

return (
<div>
    <Slider {...configuracion}>
        <div><img src='https://res.cloudinary.com/worldpackers/image/upload/c_fill,f_auto,q_auto,w_1024/v1/guides/article_cover/gwho0bfxlimmh5za3ujv' alt='Japon' /></div>
        <div><img src='https://www.intermundial.es/blog/wp-content/uploads/2017/11/9-cosas-a-saber-para-viajar-a-Tailandia-por-libre-1200x800.jpg' alt='Tahilandia' /></div>
        <div><img src='https://media.traveler.es/photos/613763e4f130191a954c703e/16:9/w_1280,c_limit/187176.jpg' alt='Hawai' /></div>
    </Slider>
</div>
)
}

export default Home
import React, { Component } from 'react'
import { useParams } from 'react-router-dom'

function Detalle()  {

    const {id} = useParams();

  
    return (
      <div>Detalle del lugar con id {id} </div>
    )

}

export default Detalle
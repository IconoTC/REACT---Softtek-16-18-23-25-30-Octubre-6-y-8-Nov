import React, { Component } from 'react'
import "../components/styles/Footer.css"

export class Footer extends Component {
  render() {
    return (
      <div>
        <h5>Pagina realizada por Anabel</h5>
      </div>
    )
  }
}

export default Footer
import React, { Component } from 'react'

export class Error extends Component {
  render() {
    return (
      <div>Error</div>
    )
  }
}

export default Error
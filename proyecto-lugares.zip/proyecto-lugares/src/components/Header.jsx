import React, { Component } from 'react'
import "../components/styles/Header.css"

import spain from '../images/banderas/spain.png';
import inglaterra from '../images/banderas/inglaterra.png';
import francia from '../images/banderas/francia.png';
import alemania from '../images/banderas/alemania.png';

import i18n from '../i18n';
import { withTranslation } from 'react-i18next';

function Header({t}) {

    const cambiarIdioma = (nuevoIdioma) => {
      i18n.changeLanguage(nuevoIdioma)
    }

    return (
      <div>
        <h1> {t('titulo')} </h1>

        <span>
          <img src={spain} onClick={() => cambiarIdioma('es')} />
          <img src={inglaterra} onClick={() => cambiarIdioma('en')} />
          <img src={francia} onClick={() => cambiarIdioma('fr')} />
          <img src={alemania} onClick={() => cambiarIdioma('de')} />
        </span>
      </div>
    )

}

export default withTranslation() (Header);
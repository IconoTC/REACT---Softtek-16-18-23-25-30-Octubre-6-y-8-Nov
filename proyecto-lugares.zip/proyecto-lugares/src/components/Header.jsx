import React, { Component } from 'react'
import "../components/styles/Header.css"

export class Header extends Component {
  render() {
    return (
      <div>
        <h1>Proyecto Turismo</h1>
      </div>
    )
  }
}

export default Header
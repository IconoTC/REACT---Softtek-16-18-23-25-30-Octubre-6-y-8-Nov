import React, { Component } from 'react'
import axios from 'axios';

export class Equipo extends Component {

  constructor(){
      super();
      this.state = {
        personas: []
      }
  }

  async componentDidMount(){
      const respuesta = await axios.get("https://rickandmortyapi.com/api/character");

      console.log(respuesta.data.results)
      this.setState({
        personas: respuesta.data.results
      })
  }

  render() {
    return (
      <div className="row">
        
          {this.state.personas.map( (miembro) => {
            return(
              <div className="card col-3" key={miembro.id}>
                <img src={miembro.image} className="card-img-top" alt={miembro.name} />
                <div className="card-body">
                  <h5 className="card-title">{miembro.name}</h5>
                  <p className="card-text">{miembro.location.name}</p>
                </div>
                <ul className="list-group list-group-flush">
                  <li className="list-group-item">Genero: {miembro.gender}</li>
                  <li className="list-group-item">Especie: {miembro.species}</li>
                  <li className="list-group-item">Estado: {miembro.status}</li>
                </ul>

            </div>
            )
          }  )}

      </div>
    )
  }
}

export default Equipo




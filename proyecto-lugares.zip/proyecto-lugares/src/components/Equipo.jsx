import React, { Component } from 'react'

export class Equipo extends Component {
  render() {
    return (
      <div>Equipo</div>
    )
  }
}

export default Equipo
import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';

import {Route, Routes} from 'react-router-dom'
import Home from './components/Home';
import Lugares from './components/Lugares';
import Equipo from './components/Equipo';
import Error from './components/Error';
import Header from './components/Header';
import Footer from './components/Footer';

import { withTranslation } from 'react-i18next';

function App({t}) {
  return (
    <div className="container">

      <header>
          <Header />
      </header>

      <nav>
          <Navbar />
      </nav>
      
      <section>
        <Routes>
          <Route exact path='/' element={<Home />} />
          <Route exact path='/home' element={<Home />} />
          <Route exact path='/lugares' element={<Lugares />} />
          <Route exact path='/equipo' element={<Equipo />} />
          <Route exact path='*' element={<Error />} />
        </Routes>
      </section>

      <footer>
        <Footer />
      </footer>

    </div>
  );
}

export default  withTranslation() (App);

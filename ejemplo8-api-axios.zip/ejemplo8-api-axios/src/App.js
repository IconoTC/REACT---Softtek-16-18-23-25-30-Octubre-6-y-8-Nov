import logo from './logo.svg';
import './App.css';

import Pokemons from './components/Pokemons';

function App() {
  return (
    <div>
      <Pokemons />
    </div>
  );
}

export default App;

import './App.css';
import React from 'react';

class App extends React.Component {

  isInvalid = false;

  constructor(props){
    super();

    this.state = {
      form: {
        nombre:'',
        edad:''
      }
    }
  }

  handleChange = e => {
    this.setState({
      form: {
        ...this.state.form,
        [e.target.name]: e.target.value
      }
    })
  }

  validar = () => {
      let errores = {};

      // Validar nombre
      if ( !(this.state.form.nombre).match(/^[A-Z][a-z]+$/) ){
          errores['nombre'] = 'El nombre solo puede contener letras y la primera mayuscula';
          this.isInvalid = true;
      }

      if (!this.state.form.nombre.length > 0){
          errores['nombre'] = 'El nombre no debe estar vacio';
          this.isInvalid = true;
      }

      // Validar edad
      if (this.state.form.edad < 18){
          errores['edad'] = 'Debes ser mayor de edad';
          this.isInvalid = true;
      }

      this.setState(
        {errors: errores}
      );
  }

  render(){
    return (
      <div>
        <form>
          <div>
            <label> Nombre: </label>
            <input type="text" name="nombre" onChange={this.handleChange} />
            <span style={{color: 'red'}}>
              {this.isInvalid && this.state.errors.nombre}
            </span>
          </div>
  
          <div>
            <label> Edad: </label>
            <input type="number" name="edad" onChange={this.handleChange} />
            <span style={{color: 'red'}}>
              {this.isInvalid && this.state.errors.edad}
            </span>
          </div>
  
          <input type="button" value="Validar" onClick={this.validar} />
        </form>
      </div>
    );
  }
  
}

export default App;

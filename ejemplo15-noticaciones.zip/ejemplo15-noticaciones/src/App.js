import logo from './logo.svg';
import './App.css';
import Notificaciones from './components/Notificaciones';

function App() {
  return (
    <div>
      <Notificaciones />
    </div>
  );
}

export default App;

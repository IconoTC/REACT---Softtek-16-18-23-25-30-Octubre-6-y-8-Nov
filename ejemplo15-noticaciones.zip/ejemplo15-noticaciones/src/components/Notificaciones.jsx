import React, { Component } from 'react'
import { NotificationContainer, NotificationManager } from 'react-notifications'
import 'react-notifications/lib/notifications.css'

export class Notificaciones extends Component {

    lanzarNotificacion(tipo){
        return () => {
            switch(tipo){
                case 'info':
                    NotificationManager.info(
                        "Ejemplo info, pulsa para ampliar informacion", 
                        "Titulo",
                        1000,
                        () => {
                            alert("Informacion ampliada");
                        },
                        true)
                    break;
                case 'success':
                    NotificationManager.success("Ejemplo success")
                    break;
                case 'error':
                    NotificationManager.error("Ejemplo error")
                    break;
                case 'warning':
                    NotificationManager.warning("Ejemplo warning")
                    break;
            }
        }
    }

    render() {
        return (
        <div>
            <button onClick={this.lanzarNotificacion('info')}>Notificacion info</button>
            <button onClick={this.lanzarNotificacion('success')}>Notificacion success</button>
            <button onClick={this.lanzarNotificacion('error')}>Notificacion error</button>
            <button onClick={this.lanzarNotificacion('warning')}>Notificacion warning</button>

            <div>
                <NotificationContainer />
            </div>
        </div>
        )
    }
}

export default Notificaciones
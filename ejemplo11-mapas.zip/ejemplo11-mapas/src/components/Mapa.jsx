import React, { Component } from 'react';
import GoogleMapReact from 'google-map-react';
import './Mapa.css';

const Etiqueta = ({text}) => <div>{text}</div>


export class Mapa extends Component {

    static defaultProps = {
        posicion: {
            lat: 40.481439,
            lng: -3.8552678
        },
        zoom: 17
    }



  render() {
    return (
      <div className='mapa'>
        <GoogleMapReact  
            bootstrapURLKeys={{key: ''}}
            defaultCenter={this.props.posicion} 
            defaultZoom={this.props.zoom}>


                <Etiqueta
                    lat={40.481439}
                    lng={-3.8552678}
                    text="Softtek, Aqui estamos" />

        </GoogleMapReact>
      </div>
    )
  }
}

export default Mapa
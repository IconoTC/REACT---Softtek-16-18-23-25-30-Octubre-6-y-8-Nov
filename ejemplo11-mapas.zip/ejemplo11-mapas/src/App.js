import logo from './logo.svg';
import './App.css';
import Mapa from './components/Mapa';

function App() {
  return (
    <div className="App">
      <Mapa />
    </div>
  );
}

export default App;

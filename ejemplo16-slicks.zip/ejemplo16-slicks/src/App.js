import logo from './logo.svg';
import './App.css';
import SliderTexto from './components/SliderTexto';

import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import SliderImagenes from './components/SliderImagenes';

function App() {
  return (
    <div>
      <SliderTexto />
      <SliderImagenes />
    </div>
  );
}

export default App;

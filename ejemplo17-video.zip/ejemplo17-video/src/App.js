import './App.css';
import { Player } from 'video-react';
import 'video-react/dist/video-react.css';

function App() {
  return (
    <div>
      <Player 
        src="https://media.w3.org/2010/05/sintel/trailer.mp4"
        // Para que funcione autoPlay tiene que estar el video muteado
        muted={true}
        autoPlay />
    </div>
  );
}

export default App;

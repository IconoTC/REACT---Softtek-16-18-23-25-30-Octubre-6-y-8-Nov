// rce intro genera la clase

import React, { Component } from 'react'

export class Titulo extends Component {
  render() {
    return (
      <h1>Crear nuevo producto</h1>
    )
  }
}

export default Titulo
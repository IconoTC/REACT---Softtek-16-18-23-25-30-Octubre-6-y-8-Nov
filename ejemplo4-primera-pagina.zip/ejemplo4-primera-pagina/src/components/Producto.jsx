import React from 'react';
import './styles/Producto.css';

class Producto extends React.Component{

    // Lo minimo que necesita un componente es el metodo render()
    render(){
        return(
            <div>
                <div className="card fondo" style={{width: 20 + 'rem'}}>
                    <img src={this.props.imagen} className="card-img-top" alt={this.props.nombre} />
                    <div className="card-body">
                        <h5 className="card-title">{this.props.nombre}</h5>
                        <p className="card-text">{this.props.descripcion}</p>
                    </div>
                    <ul className="list-group list-group-flush">
                        <li className="list-group-item">Precio: {this.props.precio}</li>
                        <li className="list-group-item">Fabricante: {this.props.fabricante}</li>
                    </ul>
                </div>
            </div>
        );
    }
}

export default Producto;
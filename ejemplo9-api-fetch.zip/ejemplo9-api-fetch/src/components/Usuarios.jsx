import React, { Component } from 'react'
import usuariosService from '../services/usuariosService';

export class Usuarios extends Component {

    constructor(){
        super();

        this.state = {
            lista_usuarios: []
        }
    }

    async componentDidMount(){
        this.setState({
            lista_usuarios:  await usuariosService.usuarios.list()
        })
    }

    render() {
        console.log(this.state.lista_usuarios);
        return (
        <div>
            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>USERNAME</th>
                        <th>EMAIL</th>
                        <th>WEBSITE</th>
                    </tr>
                </thead>
                {this.state.lista_usuarios.map( (user) => {
                    return(
                        <tr>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.username}</td>
                            <td>{user.email}</td>
                            <td>{user.website}</td>
                        </tr>
                    )
                } )}
            </table>
        </div>
        )
    }
}

export default Usuarios
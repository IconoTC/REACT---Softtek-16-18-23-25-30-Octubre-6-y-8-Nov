const url = "https://jsonplaceholder.typicode.com/users";

const llamarAPI = async(options={}) => {

    // Establecer las cabeceras
    options.headers = {
        'Content-Type':'application/json',
        Accept:'application/json'
    }

    // Enviamos la peticion de forma asincrona
    const respuesta = await fetch(url, options);
    return respuesta.json();
} 


const usuariosService = {
    usuarios:{
        list(){
            return llamarAPI();
        }
    }
}

export default usuariosService;
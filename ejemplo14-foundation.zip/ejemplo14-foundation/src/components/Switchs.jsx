import React, { Component } from 'react'
import { Switch, SwitchCheckedLabel, SwitchUncheckedLabel } from 'react-foundation-components/lib/switch'

export class Switchs extends Component {
  render() {
    return (
      <div>
        <Switch />
        <Switch defaultChecked />

        <div>
            <Switch size="tiny" />
            <Switch size="small"/>
            <Switch />
            <Switch size="large" />
        </div>

        <div>
            <Switch>
                <SwitchCheckedLabel>On</SwitchCheckedLabel>
                <SwitchUncheckedLabel>Off</SwitchUncheckedLabel>
            </Switch>    
        </div>

      </div>
    )
  }
}

export default Switchs
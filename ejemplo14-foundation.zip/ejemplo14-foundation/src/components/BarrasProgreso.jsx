import React, { Component } from 'react'
import { ProgressBar } from 'react-foundation-components/lib/progress-bar'

export class BarrasProgreso extends Component {

    porcentaje(percent){
        const rounded = Math.round(percent * 100);
        return `${rounded}%`;
    }

  render() {
    return (
      <div>
        <ProgressBar />
        <ProgressBar value={50} />
        <ProgressBar color="alert" value={25} />
        <ProgressBar min={0} max={20} value={10} />
        <ProgressBar value={50} labelFormatter={this.porcentaje}/>
      </div>
    )
  }
}

export default BarrasProgreso
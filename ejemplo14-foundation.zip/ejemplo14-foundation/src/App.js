import './App.css';
import BarraProgresoDinamica from './components/BarraProgresoDinamica';
import BarrasProgreso from './components/BarrasProgreso';
import Botones from './components/Botones';
import Switchs from './components/Switchs';

function App() {
  return (
    <div>
      <Botones />
      <Switchs />
      <BarraProgresoDinamica />
      <BarrasProgreso />
    </div>
  );
}

export default App;

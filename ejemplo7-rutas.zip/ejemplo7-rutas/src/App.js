import logo from './logo.svg';
import './App.css';

import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Navbar from './components/Navbar';
import Componente1 from './components/Componente1';
import Componente2 from './components/Componente2';
import Componente3 from './components/Componente3';
import Error from './components/Error';

function App() {
  return (
    <div>
      <BrowserRouter>
          <div>
            <Navbar />

            <Routes>
              <Route exact path='c1' element={<Componente1 />} />
              <Route exact path='c2' element={<Componente2 />}/>
              <Route exact path='c3' element={<Componente3 />}/>
              <Route path='*' element={<Error />} />
            </Routes>

          </div>
      </BrowserRouter>
    </div>
  );
}

export default App;

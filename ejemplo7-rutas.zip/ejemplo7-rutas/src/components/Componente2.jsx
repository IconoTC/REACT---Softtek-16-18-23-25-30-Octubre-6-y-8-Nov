import React, { Component } from 'react'

export class Componente2 extends Component {
  render() {
    return (
      <div>Componente2</div>
    )
  }
}

export default Componente2
import React, { Component } from 'react'
import {Link} from 'react-router-dom'

export class Navbar extends Component {
  render() {
    return (
      <div>
        <Link to="/c1">Componente 1</Link>  |  
        <Link to="/c2">Componente 2</Link>  |  
        <Link to="/c3">Componente 3</Link> 
      </div>
    )
  }
}

export default Navbar

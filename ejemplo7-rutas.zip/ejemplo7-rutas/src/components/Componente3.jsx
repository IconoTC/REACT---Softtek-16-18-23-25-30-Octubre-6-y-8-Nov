import React, { Component } from 'react'

export class Componente3 extends Component {
  render() {
    return (
      <div>Componente3</div>
    )
  }
}

export default Componente3
import React, { Component } from 'react'

export class Error extends Component {
  render() {
    return (
      <div>Error 404</div>
    )
  }
}

export default Error
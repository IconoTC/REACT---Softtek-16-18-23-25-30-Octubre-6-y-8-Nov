import React, { Component } from 'react'

export class Componente1 extends Component {
  render() {
    return (
      <div>Componente1</div>
    )
  }
}

export default Componente1
import React from 'react';
import logo from '../logo.svg';
import './styles/Producto.css';

class Producto extends React.Component{

    // Lo minimo que necesita un componente es el metodo render()
    render(){
        return(
            /*
            <>
                <div>
                    <img src={logo} />
                </div>
                
                <div className='fondo'>
                    <h1>Detalle del producto</h1>
                    <h2>Nombre: {this.props.nombre} </h2>
                    <h2>Descripcion: {this.props.descripcion}</h2>
                    <h2>Precio: {this.props.precio}</h2>
                    <h2>Fabricante: {this.props.fabricante}</h2>
                </div>      
                <div>
                    <img src={this.props.imagen}  />
                </div>
            </>
            */

            <>
                <div className="card" style={{width: 20 + 'rem'}}>
                    <img src={this.props.imagen} className="card-img-top" alt={this.props.nombre} />
                    <div className="card-body">
                        <h5 className="card-title">{this.props.nombre}</h5>
                        <p className="card-text">{this.props.descripcion}</p>
                    </div>
                    <ul className="list-group list-group-flush">
                        <li className="list-group-item">Precio: {this.props.precio}</li>
                        <li className="list-group-item">Fabricante: {this.props.fabricante}</li>
                    </ul>
                </div>
            </>
        );
    }
}

export default Producto;
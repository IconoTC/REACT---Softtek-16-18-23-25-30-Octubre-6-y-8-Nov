import logo from './logo.svg';
import './App.css';
import Producto from './components/Producto';
import Entrada from './components/Entrada';

// Crear un objeto JSON con los datos del producto
const atributos = {
  nombre: 'Impresora',
  descripcion: 'Laser multifuncion',
  precio: 140,
  fabricante: 'Brother',
  imagen: 'https://www.brother.eu/-/media/product-images/devices/printers/dcpj/dcpj562dw/es/dcpj562dw_main.png?rev=77bdd5da03e447c7b02a57e7e47e068c'
};


function App() {
  return (
    <div>
      <Producto nombre="Portatil" descripcion="16Gb RAM, 500Gb Disco Duro ...."
          precio="799" fabricante="HP"
          imagen="https://www.hp.com/es-es/shop/Html/Merch/Images/c07978044_1750x1285.jpg" />
      {/* comentario spread */}
      <Producto {...atributos} />  

      <Entrada id={1} type='text' /> <br/>
      <Entrada id={2} type='number' /> <br/>
      <Entrada id={3} type='file' /> <br/>
      <Entrada id={4} type='color' /> <br/>
      <Entrada id={5} type='date' /> <br/>
      <Entrada id={6} type='password' /> <br/>
    </div>
  );
}

export default App;

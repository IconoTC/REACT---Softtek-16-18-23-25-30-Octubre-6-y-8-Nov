import logo from './logo.svg';
import './App.css';
import MisAlumnos from './components/MisAlumnos';

function App() {
  return (
    <div>
      <MisAlumnos />
    </div>
  );
}

export default App;

import { initializeApp } from "firebase/app";
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyANffnI2S986oW88AZDAMx1178ls1f5ADw",
  authDomain: "react-anabel-c9ac7.firebaseapp.com",
  projectId: "react-anabel-c9ac7",
  storageBucket: "react-anabel-c9ac7.appspot.com",
  messagingSenderId: "343835799090",
  appId: "1:343835799090:web:33081b5e62c97d8dae162b"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
export {db};
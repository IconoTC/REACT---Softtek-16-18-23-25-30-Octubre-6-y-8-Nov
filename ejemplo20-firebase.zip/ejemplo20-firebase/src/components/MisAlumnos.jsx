// rce -> crear la clase
// rfce -> crea la funcion

import { db } from '../firebase';
import React from 'react';
import {addDoc, collection, onSnapshot, query } from 'firebase/firestore';
import { useState, useEffect } from 'react';
import Alumno from './Alumno';

function MisAlumnos() {

    // Crear el estado del componente
    const [alumnos, setAlumnos] = useState([])
    const [nombre, setNombre] = useState('')
    const [nota, setNota] = useState(0)

    useEffect( () => {
        // lanzar la peticion a la bbdd
        const alumnosDB = query(collection(db, 'alumnos'))

        // Nos mantenemos a la escucha de cualquier cambio en la BBDD
        onSnapshot(alumnosDB, (snapshot) => {
            // Guardamos los alumnos en el estado
            setAlumnos(snapshot.docs.map(doc => ({
                id: doc.id,
                data: doc.data()
            })))
        })
    }, [])

    const handleSubmit = async (e) => {
        // Cancelar el evento submit
        e.preventDefault();

        // Enviar los datos a firebase
        try{
            await addDoc(collection(db, 'alumnos'), {
                nombre: nombre,
                nota: parseFloat(nota)
            })
            // Limpiar los campos del formulario
            setNombre('')
            setNota('')
        } catch(error){
            console.log(error);
        }
    }

    return (
        <div>
            <h1>Gestion de alumnos</h1>
            <h2>Lista de alumnos</h2>
            {alumnos.map( (alum) => (
                <Alumno id={alum.id} key={alum.id}  nombre={alum.data.nombre} nota={alum.data.nota} />
            ))}

            <h2>Agregar nuevo alumno</h2>
            <form onSubmit={handleSubmit}>
                <label>Nombre:</label>
                <input type='text' name='nombre' value={nombre} 
                    onChange={ (e) => setNombre(e.target.value) } /> <br/>

                <label>Nota:</label>
                <input type='text' name='nota' value={nota} 
                    onChange={ (e) => setNota(e.target.value) } /> <br/>

                <button type='submit'>Agregar</button>
            </form>
        </div>
    )
}

export default MisAlumnos
import { doc, updateDoc } from 'firebase/firestore';
import React from 'react'
import { useState } from 'react';
import { db } from '../firebase';

function EditarAlumno({id, editNombre, editNota, onClose}) {

    const [nombre, setNombre] = useState(editNombre)
    const [nota, setNota] = useState(editNota)

    const actualizarAlumno = async (e) => {
        // Cancelamos el submit
        e.preventDefault()
        if (window.confirm("Estas seguro de modificar alumno")){
            const actualizar = doc(db, 'alumnos', id)
            try{
                await updateDoc(actualizar, {
                    nombre: nombre,
                    nota: parseFloat(nota)
                })
                onClose()
            } catch (error){
                console.log(error)
            }
        } else {
            alert("Modificacion cancelada")
        }
    }


    return (
        <div>
            <h2>Modificar alumno</h2>
            <form onSubmit={actualizarAlumno}>
                <label>Nombre:</label>
                <input type='text' name='nombre' value={nombre} 
                    onChange={ (e) => setNombre(e.target.value) } /> <br/>

                <label>Nota:</label>
                <input type='text' name='nota' value={nota} 
                    onChange={ (e) => setNota(e.target.value) } /> <br/>

                <button type='submit'>Guardar cambios</button>
            </form>
        </div>
    )
}

export default EditarAlumno
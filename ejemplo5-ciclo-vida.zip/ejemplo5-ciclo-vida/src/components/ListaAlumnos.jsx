import React, { Component } from 'react'

export class ListaAlumnos extends Component {
  render() {
    return (
      <div>
            <h1>Lista de alumnos</h1>
            <ul>
                {this.props.lista.map((alumno, index) => {
                    return(
                        <li key={index}>
                            Nombre: {alumno.nombre}, Nota: {alumno.nota}
                        </li>
                    )
                })}
            </ul>
      </div>
    )
  }
}

export default ListaAlumnos
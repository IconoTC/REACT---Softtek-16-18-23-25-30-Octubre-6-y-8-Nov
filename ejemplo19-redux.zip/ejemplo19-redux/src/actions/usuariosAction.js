import axios from 'axios';

export const traerTodos = () => async(dispatch) => {
    const respuesta = await axios.get('https://jsonplaceholder.typicode.com/users');
    console.log(respuesta);

    // El dispatch es quien dispara la llamada y contacta
    // con el reducer para que este ultimo actualice
    // la lista de usuarios en el state
    dispatch({
        type: 'pedir_usuarios',
        payload: respuesta.data
    })
}
import { combineReducers } from "redux";
import usuariosReducer from './usuariosReducer';

export default combineReducers({
    usuariosReducer
})
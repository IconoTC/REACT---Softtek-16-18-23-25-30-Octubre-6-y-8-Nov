import React, { Component } from 'react'
import { connect } from 'react-redux';
import * as usuariosAction from '../actions/usuariosAction';

export class Usuarios extends Component {

    componentDidMount(){
        this.props.traerTodos();
    }

  render() {
    return (
      <div>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOMBRE</th>
                    <th>EMAIL</th>
                    <th>WEBSITE</th>
                </tr>
            </thead>
            <tbody>
                {this.props.usuarios.map( (user) => {
                    return(
                        <tr key={user.id}>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>{user.website}</td>
                        </tr>
                    )
                } )}
            </tbody>
        </table>
      </div>
    )
  }
}

// Crear una funcion que me devuelve el reducer o los reducers
// a los que quiero conectar el componente
const mapStateToProps = (reducers) => {
    return reducers.usuariosReducer;
}

export default connect(mapStateToProps, usuariosAction)  (Usuarios)
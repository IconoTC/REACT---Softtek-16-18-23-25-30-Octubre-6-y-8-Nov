import './App.css';
import Usuarios from './components/Usuarios';

function App() {
  return (
    <div>
      <Usuarios />
    </div>
  );
}

export default App;

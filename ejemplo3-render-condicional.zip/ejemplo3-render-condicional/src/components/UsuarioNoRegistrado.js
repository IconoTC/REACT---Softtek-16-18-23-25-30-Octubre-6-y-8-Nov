// rce intro genera la clase

import React, { Component } from 'react'

export class UsuarioNoRegistrado extends Component {
  render() {
    return (
      <div>Inicie sesion</div>
    )
  }
}

export default UsuarioNoRegistrado
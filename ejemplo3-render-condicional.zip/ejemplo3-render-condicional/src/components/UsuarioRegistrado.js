// rce intro genera la clase

import React, { Component } from 'react'

export class UsuarioRegistrado extends Component {
  render() {
    return (
      <div>Bienvenido a mi app</div>
    )
  }
}

export default UsuarioRegistrado
import React, { Component } from 'react'

export class TodoForm extends Component {

    constructor(){
        super();

        this.state = {
            tarea: ''
        }
    }

    guardarTarea = e => {
        this.setState(
            {tarea: e.target.value}
        )
    }

    render() {
        return (
        <div>
            <form onSubmit={this.props.onSubmit}>
                <label>Tarea:</label>
                <input type='text' name='tarea' value={this.state.tarea} onChange={this.guardarTarea} />
                <input type='submit' value="Agregar tarea" />
            </form>

        </div>
        )
    }
}

export default TodoForm
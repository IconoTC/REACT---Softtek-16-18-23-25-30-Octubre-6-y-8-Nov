import logo from './logo.svg';
import './App.css';
import TodoForm from './components/TodoForm';
import TodoList from './components/TodoList';

import React from 'react'

class App extends React.Component {

  constructor(){
    super();

    // Crear el estado
    this.state = {
      arrayDatos: []
    }
  }

  handleSubmit = e => {
    // Cancelar el submit
    e.preventDefault();

    // El valor recibido lo agrego al estado
    let valor = Object.fromEntries(new FormData(e.target));
    console.log(valor.tarea);
    this.setState(
      {arrayDatos: this.state.arrayDatos.concat(valor.tarea)}
    );
  }

  render(){
    return (
      <div>
        <TodoForm onSubmit={this.handleSubmit} />
        <TodoList coleccion={this.state.arrayDatos} />
      </div>
    );
  }
}

export default App;

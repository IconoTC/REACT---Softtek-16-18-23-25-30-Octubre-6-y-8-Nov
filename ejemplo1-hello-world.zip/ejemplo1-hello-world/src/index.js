// Contenido JavaScript
/*
const contenedor = document.getElementById('root');
const elemento = document.createElement('h1');
elemento.innerText = 'Bienvenidos al curso de React!!';
contenedor.appendChild(elemento);
*/

// Contenido JSX
import React from 'react';
import ReactDOM from 'react-dom/client';

const jsx = <h1>Bienvenidos al curso de React!!</h1>;
const contenedor = ReactDOM.createRoot(document.getElementById('root'));
contenedor.render(jsx);

// Otra forma de crear elementos
// React.createElement(elemento, atributos, children)
const enlace = React.createElement('a', {href:'http://google.es'}, 'Ir a Google');
contenedor.render(enlace);

// Introducimos variables
const nombre = 'Pepito';
const msgPersonalizado = React.createElement('h1', {}, `Bienvenid@ ${nombre} al curso de React`);
contenedor.render(msgPersonalizado);

// JSX es mucho mas limpio
const jsx2 = <h1>Bienvenid@  {nombre} al curso de React!!</h1>;
contenedor.render(jsx2);

// Resolver expressiones
const jsx3 = <h2>Suma: 7 + 2 = {7 + 2}</h2>;
contenedor.render(jsx3);

// Invocar a metodos
const multiplicacion = () => 7*2;
const jsx4 = <h2>Multiplicacion: 7 x 2 = {multiplicacion()}</h2>;
contenedor.render(jsx4);


// Renderizar mas de un elemento
const elementoMultiple = React.createElement(
  'div',
  {},
  React.createElement('h1', {}, `Bienvenid@ ${nombre} al curso de React`),
  React.createElement('a', {href:'http://google.es'}, 'Ir a Google') 
);
contenedor.render(elementoMultiple);

const jsx5 = (
  <div>
    <h1>Bienvenid@  {nombre} al curso de React!!</h1>
    <a href='http://google.es'>Ir a Google</a>
  </div>
);
contenedor.render(jsx5);

// Los valores que se resuelven como false, null, undefined
// React los ignora y no los renderiza
const jsx6 = <h1>Valor false {false} </h1>;
contenedor.render(jsx6);
import logo from './logo.svg';
import './App.css';
import { withTranslation } from 'react-i18next';
import i18n from './i18n';


function App({t}) {

  const cambiarIdioma = (nuevoIdioma) => {
    i18n.changeLanguage(nuevoIdioma);
  }

  return (
    <div className="App">
      <a onClick={() => cambiarIdioma('es')}>Español</a>  |
      <a onClick={() => cambiarIdioma('en')}>Ingles</a>


      <h1>{t('mensaje')}</h1>
    </div>
  );
}

export default withTranslation() (App);
